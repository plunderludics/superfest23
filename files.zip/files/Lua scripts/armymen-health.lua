health_addr = 0x75ECD0
hp = 0

while true do
    prevhp = hp;
    hp = memory.read_u32_be(health_addr, "RDRAM")

    gui.clearGraphics();
    gui.drawText(100, 40, hp);

    if (hp < prevhp) then
        unityhawk.callmethod("Hurt", hp);
    end

    emu.yield()
end
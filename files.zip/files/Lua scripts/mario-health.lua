health_addr = 0x33B21E

while true do
    -- hp = memory.read_u8(health_addr, "RDRAM")

    hp = unityhawk.callmethod("GetHealth", "_");
    memory.write_u8(health_addr, tonumber(hp), "RDRAM")

    -- gui.clearGraphics();
    -- gui.drawText(100, 40, hp);

    emu.yield()
end